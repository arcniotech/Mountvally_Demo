import React from "react";

export function InstitutionLogo({
  className = "w-10 h-10",
  showText = false,
  textClassName = "",
}) {
  return (
    <div className="flex items-center gap-3">
      <div className={`relative shrink-0 ${className}`}>
        <svg
          viewBox="0 0 200 200"
          fill="none"
          className="w-full h-full rounded-2xl shadow-soft"
        >
          <rect width="200" height="200" rx="36" fill="#059669" />
          <g fill="#FFFFFF">
            {/* Mortarboard Diamond Top */}
            <path d="M100 36 L156 58 L100 80 L44 58 Z" />

            {/* Mortarboard Cap Band */}
            <path d="M68 70 C78 80 122 80 132 70 L132 82 C122 92 78 92 68 82 Z" />

            {/* Tassel */}
            <path d="M152 60 L152 92 C150 95 147 100 147 114 C150 116 156 116 158 114 C158 100 155 95 154 92 L154 60 Z" />
            <circle cx="153" cy="90" r="2.5" />

            {/* Capital Column / Pillar Body forming 'I' */}
            <path d="M64 88 C80 94 120 94 136 88 C130 102 118 114 118 140 C118 147 122 153 128 158 L122 163 C113 157 110 148 110 138 L110 98 L90 98 L90 138 C90 148 87 157 78 163 L72 158 C78 153 82 147 82 140 C82 114 70 102 64 88 Z" />

            {/* Open Book Base forming the foundation */}
            <path d="M100 166 C78 148 54 150 36 160 C48 142 74 138 98 151 L100 152 L102 151 C126 138 152 142 164 160 C146 150 122 148 100 166 Z" />
            <path d="M100 178 C74 158 48 160 28 172 C42 154 72 148 98 163 L100 164 L102 163 C128 148 158 154 172 172 C152 160 126 158 100 178 Z" />
          </g>
        </svg>
      </div>

      {showText && (
        <div className={textClassName}>
          <span className="font-extrabold text-lg sm:text-xl tracking-tight block text-slate-900 dark:text-white leading-tight">
            institution
            <span className="text-emerald-600 dark:text-emerald-400">rp</span>
          </span>
          <span className="text-[11px] text-slate-400 font-medium tracking-wide block">
            Mount Valley.com
          </span>
        </div>
      )}
    </div>
  );
}
